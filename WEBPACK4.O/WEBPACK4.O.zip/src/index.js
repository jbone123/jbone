let str  =  require('./a.js')
console.log(str);