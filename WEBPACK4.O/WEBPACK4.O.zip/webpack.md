## 1. webpack 常见配置 可以进行0配置
- 打包工具--》 输出后的结果（js模块）
- 安装本地webpack
```js
    yarn add webpack webpack-cli -D
    npx webpack //执行webpack

```
- 打包（支持我们js模块的话）
  
## 2. 手动配置webpack
- 默认配置webpack名字 webpack-cli/bin下 webpack.config.js
- webpack-dev-server  //启动一个express服务
- html-webpack-plugin // 对html做处理
- loader style-loader css-loader